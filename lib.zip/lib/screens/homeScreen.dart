import 'package:flutter/material.dart';
import 'package:poc_demo_app/models/task.dart';
import 'package:poc_demo_app/providers/home_Screen_Provider.dart';
import 'package:poc_demo_app/services/API/api.dart';
import 'package:provider/provider.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ChangeNotifierProvider<HomeScreenProvider>(
          create: (context) => HomeScreenProvider(),
          child: Container(
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'TODAY',
                        style: TextStyle(fontSize: 32),
                      ),
                      Consumer<HomeScreenProvider>(
                        builder: (context, provider, child) {
                          return Container(
                            width: 200,
                            height: 200,
                            margin: EdgeInsets.all(20),
                            child: ListView.builder(
                              itemCount: provider.taskList.length,
                              itemBuilder: (BuildContext context, int index) {
                                return MaterialButton(
                                  onPressed: () {
                                    provider.addTask(
                                      Task(
                                        id: 55,
                                        task: 'dont make game $index',
                                        isCompleted: false,
                                        dueDate: DateTime.now()
                                            .add(const Duration(days: 2)),
                                        userId: 5,
                                        createdAt: DateTime.now(),
                                        updatedAt: DateTime.now(),
                                      ),
                                    );
                                  },
                                  child: Text(provider.taskList[index].task),
                                );
                              },
                            ),
                          );
                        },
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
