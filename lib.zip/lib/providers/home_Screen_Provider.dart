import 'package:flutter/cupertino.dart';
import 'package:poc_demo_app/models/task.dart';
import 'package:poc_demo_app/services/API/api.dart';

class HomeScreenProvider with ChangeNotifier {
  List<Task> taskList = [
    Task(
      id: 55,
      task: 'Make a Game',
      isCompleted: false,
      dueDate: DateTime.now().add(const Duration(days: 2)),
      userId: 5,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    ),
  ];

  List<Task> getTasks(int pageNo) {
    return taskList;
    // if (taskList.isNotEmpty) {
    //   return taskList;
    // } else {}
    // return taskList;
  }

  void addTask(Task taskToAdd) async {
    taskList.add(taskToAdd);

    notifyListeners();

    // add todo to Database
    // if (await ApiService().addTodo(taskToAdd)) {
    //   print('added to DB');
    // }
  }
}
