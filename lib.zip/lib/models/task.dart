import 'dart:convert';

class Task {
  Task({
    required this.id,
    required this.task,
    required this.isCompleted,
    required this.dueDate,
    required this.userId,
    this.deletedAt,
    required this.createdAt,
    required this.updatedAt,
  });

  int id;
  String task;
  bool isCompleted;
  DateTime dueDate;
  int userId;
  dynamic deletedAt;
  DateTime createdAt;
  DateTime updatedAt;
}
